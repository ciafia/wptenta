
<!-- Site footer -->
      <footer class="footer">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <p>Author: Cia Alnerheim</p>
            </div>
            <div class="col-md-6 text-right">
              <p>&copy; 2017</p>
            </div>
          </div>
        </div>
        
      </footer>

<?php wp_footer(); ?>
  </body>
</html>
      