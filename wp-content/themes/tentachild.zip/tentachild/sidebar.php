<div class="sidebar">
	<ul class="list-unstyled">
		<?php
			if (is_active_sidebar('blog-sidebar')){
				dynamic_sidebar('blog-sidebar');
			}
		?>
		
	</ul>
</div>	